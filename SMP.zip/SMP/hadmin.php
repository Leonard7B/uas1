<?php
include ("koneksi.php");
$id = $_GET['id'];
$hapus=mysqli_query($koneksi,"DELETE FROM admin WHERE id='$id'") or die (mysqli_error());

if($hapus) {
	header("Location:index.php?z=admin");
	echo "<script>alert('Data Admin Berhasil Dihapus');window.location='index.php'</script>";
}