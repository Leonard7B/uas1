<?php
$koneksi=mysqli_connect("localhost","root","","smp");
if (!$koneksi) {
    die("Koneksi gagal: " . mysqli_connect_error());
}

?>
