<?php
include("koneksi.php");
$nama_siswa= $_POST['txtSiswa'];
$nisn= $_POST['txtNisn'];
$alamat= $_POST['txtAlamat'];
$gender= $_POST['gender'];
$agama= $_POST['txtAgama'];
$nilai= $_POST['txtNilai'];


$simpan= mysqli_query($koneksi,"INSERT into siswa(nama_siswa, nisn, alamat, gender, agama, nilai)
	values('$nama_siswa','$nisn','$alamat','$gender','$agama', '$nilai')") or die (mysqli_error());
if ($simpan) {
	header("Location:index.php?z=siswa");
} 
else{
    echo "gagal disimpan";
}
?>