<?php
include("koneksi.php");
$nama_siswa= $_POST['txtSiswa'];
$nisn= $_POST['txtNisn'];
$alamat= $_POST['txtAlamat'];
$gender= $_POST['gender'];
$agama= $_POST['txtAgama'];
$nilai= $_POST['txtNilai'];

$simpan= mysqli_query($koneksi,"UPDATE siswa SET nama_siswa='$nama_siswa', nisn='$nisn', alamat='$alamat', 
gender='$gender', agama='$agama', nilai='$nilai' WHERE id_siswa='$kode'");
if ($simpan) {
	header("Location:index.php?z=siswa");
}
?>