<?php
include ("koneksi.php");
$id = $_GET['id'];
$hapus=mysqli_query($koneksi,"DELETE FROM siswa WHERE id_siswa='$id'");
if($hapus) {
	header("Location:index.php?z=siswa");
}
