<?php
if (isset($_GET['z'])){
    switch ($_GET['z']){
        case 'keluar':
            include("keluar.php");
            break;
        case 'admin':
            include("admin.php");
            break;
        case 'tadmin':
            include("tadmin.php");
            break;
        case 'sadmin':
            include("sadmin.php");
            break;
        case 'hadmin':
            include("hadmin.php");
            break;
        case 'eadmin':
            include("eadmin.php");
            break;
        case 'uadmin':
            include("uadmin.php");
            break;
        case 'siswa':
            include("siswa.php");
            break;
        case 'tsiswa':
            include("tsiswa.php");
            break;
        case 'ssiswa':
            include("ssiswa.php");
            break;
        case 'hsiswa':
            include("hsiswa.php");
            break;
        case 'esiswa':
            include("esiswa.php");
            break;
        case 'usiswa':
            include("usiswa.php");
            break;
        case 'rsiswa':
            include("rsiswa.php");
            break;
    }
}
else{
    echo  "<h4  class=mx-auto font-weight-bold>Selamat Datang di Aplikasi Input Nilai Siswa/i</h4>";
}