<?php
include("koneksi.php");
$kode= $_POST['kode'];
$nama= $_POST['txtNama'];
$jenis_kelamin= $_POST['kelamin'];
$username= $_POST['txtUsername'];
$password= $_POST['txtPassword'];
$simpan= mysqli_query($koneksi,"UPDATE admin SET nama='$nama', jenis_kelamin='$jenis_kelamin', username='$username', 
password='$password' WHERE id='$kode'") or die (mysqli_error());
if ($simpan) {
	header("Location:index.php?z=admin");
}
else{
    echo "gagal diubah";
}
?>
