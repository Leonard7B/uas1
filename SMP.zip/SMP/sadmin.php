<?php
include("koneksi.php");
$nama= $_POST['txtNama'];
$jenis_kelamin= $_POST['kelamin'];
$username= $_POST['txtUsername'];
$password= $_POST['txtPassword'];
$simpan= mysqli_query($koneksi,"INSERT into admin(nama, jenis_kelamin, username, password)
	values('$nama','$jenis_kelamin','$username','$password')") or die (mysqli_error());
if ($simpan) {
    header("Location:index.php?z=admin");
}
else{
    echo "gagal disimpan";
}

?>
